/*
** wolf3d.h for wolf in /u/all/duplan_k/cu/rendu/c/wolf3d
** 
** Made by kevin duplant
** Login   <duplan_k@epitech.net>
** 
** Started on  Wed Jan 20 12:51:39 2010 kevin duplant
** Last update Wed Jan 20 15:17:18 2010 kevin duplant
*/

#ifndef __WOLF3D_H__
# define __WOLF3D_H__

#define LENGHT 800
#define HEIGHT 600

typedef struct	s_image
{
  void	*mlx_ptr;
  void	*win_ptr;
  void	*img_ptr;
  char	*img;
  int	bpp;
  int	size_line;
  int	endian;
  float	x;
  float	y;
  float	k;
  float	a;
}		t_image;

int	my_putchar(char c);
int	my_putstr(char *str);
int	my_strlen(char *str);

void	aff_mur(t_image *t);
void	input_font(t_image *t);
void	insert_mur(t_image *t, int x);
void	my_create_lab(t_image *t);
void	next_of_user_touch(t_image *t, float x, float y);

#endif /* !__WOLF3D_H__ */
