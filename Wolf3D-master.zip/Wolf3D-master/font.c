/*
** font.c for wolf in /u/all/duplan_k/cu/rendu/c/wolf3d
** 
** Made by kevin duplant
** Login   <duplan_k@epitech.net>
** 
** Started on  Wed Jan 20 15:20:34 2010 kevin duplant
** Last update Wed Jan 20 15:20:35 2010 kevin duplant
*/

#include "wolf3d.h"

void	input_font(t_image *t)
{
  int	a;

  a = 0;
  while (a < (t->size_line * (HEIGHT / 2)))
    t->img[++a] = 60;
  while (a < (t->size_line * HEIGHT))
    t->img[++a] = 100;
}
