/*
** mur.c for mur in /u/all/duplan_k/cu/rendu/c/wolf3d
** 
** Made by kevin duplant
** Login   <duplan_k@epitech.net>
** 
** Started on  Wed Jan 20 12:49:55 2010 kevin duplant
** Last update Wed Jan 20 15:16:47 2010 kevin duplant
*/

#include "mlx.h"
#include "wolf3d.h"

void	mur_down(t_image *t, int y, int h)
{
  int	c;
  int	i;
  int	z;

  i = 0;
  while (i < h)
    {
      c = 0;
      while (c < (t->bpp / 8))
	{
	  z = y + (i * t->size_line);
	  t->img[c + z] = 25;
	  ++c;
	}
      ++i;
    }
}

void	insert_mur(t_image *t, int x)
{
  int	i;
  int	h;
  int	c;
  int	y;
  int	z;

  h = (HEIGHT / (2 * t->k));
  y = ((HEIGHT / 2) * t->size_line) + (x * t->bpp / 8);
  i = 0;
  while (i < h)
    {
      c = 0;
      while (c < (t->bpp / 8))
	{
	  z = y - (i * t->size_line);
	  t->img[c + z] = 25;
	  ++c;
	}
      ++i;
    }
  mur_down(t, y, h);
}
