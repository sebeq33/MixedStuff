/*
** main.c for main in /u/all/duplan_k/cu/rendu/c/wolf3d
** 
** Made by kevin duplant
** Login   <duplan_k@epitech.net>
** 
** Started on  Wed Jan 20 12:49:44 2010 kevin duplant
** Last update Wed Jan 20 12:55:51 2010 kevin duplant
*/

#include <unistd.h>
#include <math.h>
#include <stdlib.h>
#include "mlx.h"
#include "wolf3d.h"

int	user_touch(int	key, t_image *t)
{
  float	x;
  float	y;

  x = -1;
  y = -1;
  if (key == 65307)
    exit(1);
  if (key == 65362)
    {
      x = t->x + (0.1 * cos((t->a / 180) * M_PI));
      y = t->y + (0.1 * sin((t->a / 180) * M_PI));
    }
  else if (key == 65364)
    {
      x = t->x - (0.1 * cos((t->a / 180) * M_PI));
      y = t->y - (0.1 * sin((t->a / 180) * M_PI));
    }
  if (key == 65363)
    t->a = t->a - 15;
  if (key == 65361)
    t->a = t->a + 15;
  next_of_user_touch(t, x, y);
  return (1);
}

int	my_gere_expose(t_image *t)
{
  mlx_put_image_to_window(t->mlx_ptr, t->win_ptr, t->img_ptr, 0, 0);
  return (0);
}

int	main()
{
  t_image	t;

  t.mlx_ptr = mlx_init();
  t.win_ptr = mlx_new_window(t.mlx_ptr, LENGHT, HEIGHT, "Wolf 3D, Have Fun!");
  t.img_ptr = mlx_new_image(t.mlx_ptr, LENGHT, HEIGHT);
  t.img = mlx_get_data_addr(t.img_ptr, &t.bpp, &t.size_line, &t.endian);
  input_font(&t);
  t.x = 13.5;
  t.y = 1.5;
  t.a = 180;
  t.k = -1;
  aff_mur(&t);
  mlx_expose_hook(t.win_ptr, my_gere_expose, &t);
  mlx_key_hook(t.win_ptr, user_touch, &t);
  mlx_loop(t.mlx_ptr);
  return (0);
}
