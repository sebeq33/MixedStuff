/*
** calculs.c for wolf in /u/all/duplan_k/cu/rendu/c/wolf3d
** 
** Made by kevin duplant
** Login   <duplan_k@epitech.net>
** 
** Started on  Wed Jan 20 15:20:10 2010 kevin duplant
** Last update Wed Jan 20 15:20:10 2010 kevin duplant
*/

#include <unistd.h>
#include <math.h>
#include <stdlib.h>
#include "mlx.h"
#include "wolf3d.h"

int	lab[15][15] =
  {
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1},
    {1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1},
    {1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1},
    {1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1},
    {1, 0, 1, 1, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1},
    {1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1},
    {1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1},
    {1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1},
    {1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
  };

float	my_calcul_k(t_image *t, float x1, float y1)
{
  int	x;
  int	y;
  float	k;

  k = 1;
  x = t->x + (k * (x1 - t->x));
  y = t->y + (k * (y1 - t->y));
  while (lab[x][y] == 0)
    {
      x = t->x + (k * (x1 - t->x));
      y = t->y + (k * (y1 - t->y));
      k += 0.01;
    }
  return (k);
}

void	aff_mur(t_image *t)
{
  float	a;
  float	tmp;
  float	x1;
  float	y1;
  float	i;

  input_font(t);
  a = ((t->a / 180) * M_PI);
  i = 0;
  while (i <= LENGHT)
    {
      x1 = 0.5;
      y1 = ((1 * ((LENGHT / 2) - i)) / LENGHT);
      tmp = x1;
      x1 = (tmp * cos(a)) - (y1 * sin(a));
      y1 = (tmp * sin(a)) + (y1 * cos(a));
      x1 = x1 + t->x;
      y1 = y1 + t->y;
      t->k = my_calcul_k(t, x1, y1);
      insert_mur(t, i);
      ++i;
    }
  mlx_put_image_to_window(t->mlx_ptr, t->win_ptr, t->img_ptr, 0, 0);
}

void	next_of_user_touch(t_image *t, float x, float y)
{
  int	a;
  int	b;

  a = x;
  b = y;
  if (x >= 0 && x <= 14 && y >= 0 && y <= 14 && lab[a][b] == 0)
    {
      t->x = x;
      t->y = y;
    }
  aff_mur(t);
  mlx_put_image_to_window(t->mlx_ptr, t->win_ptr, t->img_ptr, 0, 0);
}
