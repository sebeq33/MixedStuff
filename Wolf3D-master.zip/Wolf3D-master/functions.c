/*
** functions.c for functions in /u/all/duplan_k/cu/rendu/c/wolf3d
** 
** Made by kevin duplant
** Login   <duplan_k@epitech.net>
** 
** Started on  Wed Jan 20 12:49:27 2010 kevin duplant
** Last update Wed Jan 20 12:49:29 2010 kevin duplant
*/

#include <stdlib.h>
#include <unistd.h>
#include "wolf3d.h"

int	my_strlen(char *str)
{
  int	i;

  i = 0;
  while (str[i] && str[i] != '\0')
    ++i;
  return (i);
}

void	my_perror(char *str)
{
  write(2, str, my_strlen(str));
  exit(1);
}

int	xwrite(int out, char *str, int size)
{
  int	v;

  v = write(out, str, size);
  if (v == -1)
    my_perror("Erreur d'Ecriture!\n");
  return (v);
}

int	my_putchar(char c)
{
  return (xwrite(1, &c, 1));
}

int	my_putstr(char *str)
{
  return (xwrite(1, str, my_strlen(str)));
}
