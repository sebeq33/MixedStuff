/*
** gimme.c for gimme.c in /home/ninon_s//Dropbox/Epitech/current/wolf3D/src
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Tue Jan  1 01:35:24 2013 simon ninon
** Last update Sun Jan 13 21:09:34 2013 simon ninon
*/

#include <math.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "mlx.h"
#include "wolf.h"
#include "my_printf.h"
#include "get_next_line.h"

void	gimme_map(int fd, t_file *data_file)
{
  int	i;
  int	last_size;
  char	*tmp;

  i = 0;
  data_file->map = malloc((data_file->nbr_lines + 1)* sizeof(int *));
  if (data_file->map == NULL)
    exit(-1);
  while ((tmp = get_next_line(fd)) != NULL)
    {
      if (i && last_size != my_strlen(tmp))
	{
	  my_printf("%COLOR[Error] %COLORWrong size_line\n", "RED", "WHITE");
	  exit(0);
	}
      last_size = my_strlen(tmp);
      data_file->map[i] = malloc(my_strlen(tmp) * sizeof(int));
      if (data_file->map[i] == NULL)
	exit(0);
      transform_in_int(tmp, data_file->map[i++], &data_file->size_line);
      free(tmp);
    }
  data_file->map[i] = NULL;
}

void	gimme_win(t_win *win)
{
  if (!(win->mlx_ptr = mlx_init()))
    {
      my_printf("%COLOR[Error] %COLORmlx_init() has failed\n",
		"RED",
		"WHITE");
      exit(1);
    }
  win->win_ptr = mlx_new_window(win->mlx_ptr,
				WIN_SIZE_X,
				WIN_SIZE_Y,
				WIN_NAME);
  if (win->win_ptr == NULL)
    {
      my_printf("%COLOR[Error] %COLORNo new window.\n", "RED", "WHITE");
      exit(-1);
    }
}

void	gimme_img(t_win *win, t_img *img)
{
  img->img_ptr = mlx_new_image(win->mlx_ptr, IMG_SIZE_X, IMG_SIZE_Y);
  if (img->img_ptr == NULL)
    {
      my_printf("%COLOR[Error] %COLORNo new img.\n", "RED", "WHITE");
      exit(-1);
    }
  img->data = mlx_get_data_addr(img->img_ptr,
				&(img->bpp),
				&(img->size_line),
				&(img->endian));
  if (img->data == NULL)
    exit(-1);
}

int	gimme_nbr_lines(char *file)
{
  int	fd;
  int	nbr_lines;

  nbr_lines = 0;
  if ((fd = open(file, O_RDONLY)) == -1)
    {
      my_printf("%COLOR[Error] %COLOROpen() has failed.\n", "RED", "WHITE");
      exit(0);
    }
  while (get_next_line(fd))
    nbr_lines++;
  close(fd);
  return (nbr_lines);
}

void	gimme_color(t_data *data, double x, double y, double angle)
{
  int	case_x;
  int	case_y;

  case_x = CASE_SIZE_X(data->file->size_line);
  case_y = CASE_SIZE_Y(data->file->nbr_lines);
  if ((int)data->draw->x / case_x > (int)x / case_x)
    color_one(data);
  else if ((int)data->draw->x / case_x < (int)x / case_x)
    color_two(data);
  else if ((int)data->draw->y / case_y > (int)y / case_y)
    color_three(data);
  else if ((int)data->draw->y / case_y < (int)y / case_y)
    color_four(data);
  else
    {
      gimme_color(data,
		  x - cos(RADIAN(angle)) * data->perso->precision * 0.1,
		  y + sin(RADIAN(angle)) * data->perso->precision * 0.1,
		  angle);
    }
}
