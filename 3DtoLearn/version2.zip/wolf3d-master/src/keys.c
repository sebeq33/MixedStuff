/*
** keys.c for keys in /home/ninon_s//Dropbox/Epitech/current/wolf3D/src
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Tue Jan  1 13:40:38 2013 simon ninon
** Last update Fri Jan 11 17:27:07 2013 simon ninon
*/

#include <math.h>
#include "wolf.h"

void	right(t_data *data)
{
  int	turn;

  if (data->perso->speed == 15)
    turn = 5;
  else
    turn  = 10;
  if (data->perso->angle < 360 - turn)
    data->perso->angle += turn;
  else
    data->perso->angle = 0;
}

void	left(t_data *data)
{
  int	turn;

  if (data->perso->speed == 15)
    turn = 5;
  else
    turn  = 10;
  if (data->perso->angle == 0)
    data->perso->angle = 360;
  data->perso->angle -= turn;
}

void	up(t_data *data)
{
  float	case_x;
  float	case_y;
  float	new_x;
  float	new_y;
  float	angle;

  case_x = CASE_SIZE_X(data->file->size_line);
  case_y = CASE_SIZE_Y(data->file->nbr_lines);
  angle = RADIAN(data->perso->angle);
  new_x = cos(angle) * case_x / data->perso->speed;
  new_y = sin(angle) * case_y / data->perso->speed;
  if (data->perso->x + new_x > 0
      && data->perso->y - new_y > 0
      && data->perso->x + new_x < IMG_SIZE_X
      && data->perso->y - new_y < IMG_SIZE_Y
      && data->file->map[(int)((data->perso->y - new_y) / case_y)]
    [(int)((data->perso->x + new_x) / case_x)] == 0)
    {
      data->perso->x += new_x;
      data->perso->y -= new_y;
    }
}

void	down(t_data *data)
{
  float	case_x;
  float	case_y;
  float	new_x;
  float	new_y;
  float	angle;

  case_x = CASE_SIZE_X(data->file->size_line);
  case_y = CASE_SIZE_Y(data->file->nbr_lines);
  angle = RADIAN(data->perso->angle);
  new_x = cos(angle) * case_x / data->perso->speed;
  new_y = sin(angle) * case_y / data->perso->speed;
  if (data->perso->x - new_x > 0
      && data->perso->y + new_y > 0
      && data->perso->x - new_x < IMG_SIZE_X
      && data->perso->y + new_y < IMG_SIZE_Y
      && data->file->map[(int)((data->perso->y + new_y) / case_y)]
      [(int)((data->perso->x - new_x) / case_x)] == 0)
    {
      data->perso->x -= new_x;
      data->perso->y += new_y;
    }
}
