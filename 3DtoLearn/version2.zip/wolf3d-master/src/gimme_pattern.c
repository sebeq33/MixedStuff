/*
** gimme_pattern.c for gimme_pattern in /home/ninon_s//Dropbox/Epitech/current/wolf3D/src
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Thu Jan 10 17:52:50 2013 simon ninon
** Last update Sun Jan 13 21:11:29 2013 simon ninon
*/

#include <stdlib.h>
#include "mlx.h"
#include "wolf.h"
#include "my.h"

void	gimme_sky(t_data *data)
{
  int	*x;
  int	*y;

  x = malloc(sizeof(int));
  y = malloc(sizeof(int));
  data->background = malloc(sizeof(*(data->background)));
  if (x == NULL || y == NULL || data->background == NULL)
    exit(-1);
  data->background->img_ptr = mlx_xpm_file_to_image(data->win->mlx_ptr,
						    "textures/nyan.xpm", x, y);
  if (data->background->img_ptr == NULL)
    exit(-1);
  data->background->data = mlx_get_data_addr(data->background->img_ptr,
					     &(data->background->bpp),
					     &(data->background->size_line),
					     &(data->background->endian));
  if (data->background->data == NULL)
    exit(-1);
  data->background->x = *x;
  data->background->y = *y;
}

void	gimme_floor(t_data *data)
{
  int	*x;
  int	*y;

  x = malloc(sizeof(int));
  y = malloc(sizeof(int));
  data->floor = malloc(sizeof(*(data->floor)));
  if (x == NULL || y == NULL || data->floor == NULL)
    exit(-1);
  data->floor->img_ptr = mlx_xpm_file_to_image(data->win->mlx_ptr,
					       "textures/floor.xpm", x, y);
  if (data->floor->img_ptr == NULL)
    exit(-1);
  data->floor->data = mlx_get_data_addr(data->floor->img_ptr,
					&(data->floor->bpp),
					&(data->floor->size_line),
					&(data->floor->endian));
  if (data->floor->data == NULL)
    exit(-1);
  data->floor->x = *x;
  data->floor->y = *y;
}

void	gimme_gun(t_data *data)
{
  int	*x;
  int	*y;

  x = malloc(sizeof(int));
  y = malloc(sizeof(int));
  data->gun = malloc(sizeof(*(data->floor)));
  if (x == NULL || y == NULL || data->gun == NULL)
    exit(-1);
  data->gun->img_ptr = mlx_xpm_file_to_image(data->win->mlx_ptr,
					     "textures/gun.xpm", x, y);
  if (data->gun->img_ptr == NULL)
    exit(-1);
  data->gun->data = mlx_get_data_addr(data->gun->img_ptr,
				      &(data->gun->bpp),
				      &(data->gun->size_line),
				      &(data->gun->endian));
  if (data->gun->data == NULL)
    exit(-1);
  data->gun->x = *x;
  data->gun->y = *y;
}
