/*
** init.c for init in /home/ninon_s//Dropbox/Epitech/current/new_wolf3D/src
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Mon Dec 31 18:31:28 2012 simon ninon
** Last update Fri Jan 11 17:26:59 2013 simon ninon
*/

#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "my.h"
#include "wolf.h"
#include "my_printf.h"
#include "get_next_line.h"

void	init_perso(t_perso *perso, t_file *file)
{
  int	i;
  int	j;

  i = 0;
  while (i < file->nbr_lines)
    {
      j = 0;
      while (j < file->size_line)
	if (!file->map[i][j])
	  {
	    perso->x = (j + 0.25) * CASE_SIZE_X(file->size_line);
	    perso->y = (i + 0.25) * CASE_SIZE_Y(file->nbr_lines);
	    perso->angle = 0;
	    return ;
	  }
	else
	  j++;
      i++;
    }
  my_printf("%COLOR[Error] %COLORNo empty space.\n", "RED", "WHITE");
  exit(0);
}

t_data	*init_struct(t_data *data)
{
  data = malloc(sizeof(*data));
  data->file = malloc(sizeof(*(data->file)));
  data->win = malloc(sizeof(*(data->win)));
  data->img = malloc(sizeof(*(data->img)));
  data->perso = malloc(sizeof(*(data->perso)));
  data->draw = malloc(sizeof(*(data->draw)));
  if (data == NULL
      || data->file == NULL
      || data->win == NULL
      || data->img == NULL
      || data->perso == NULL
      || data->draw == NULL)
    {
      my_printf("%COLOR[Error] %COLORMalloc() has failed.\n", "RED", "WHITE");
      exit(0);
    }
  data->draw->minimap = 1;
  data->perso->precision = 0.1;
  data->perso->speed = 15;
  return (data);
}

void	transform_in_int(char *tmp, int *line_map, int *size_line)
{
  int	i;
  int	j;

  i = 0;
  j = 0;
  while (tmp[i])
    {
      while (tmp[i] == ' ' || tmp[i] == '\t')
	i++;
      if (tmp[i] && (tmp[i] == '0' || tmp[i] == '1'))
	line_map[j++] = my_getnbr(&tmp[i]);
      else if (tmp[i] && tmp[i] != '0' && tmp[i] != '1')
	{
	  my_printf("%COLOR[Error] %COLORWrong map.\n", "RED", "WHITE");
	  exit(0);
	}
      while (tmp[i] && tmp[i] != ' ' && tmp[i] != '\t')
	i++;
    }
  *size_line = j;
}

void	check_map(t_file *data_file)
{
  int	i;
  int	j;

  i = 0;
  while (i < data_file->nbr_lines)
    {
      j = 0;
      while (j < data_file->size_line)
	{
	  if (((!i || i == data_file->nbr_lines - 1) && !data_file->map[i][j])
	      || ((!j || j == data_file->size_line - 1) && !data_file->map[i][j]))
	{
	  my_printf("%COLOR[Error] %COLORNo Walls.\n", "RED", "WHITE");
	  exit(0);
	}
	  j++;
	}
      i++;
    }
}

void	gimme_data(t_file *data_file, char *file)
{
  int	fd;

  if ((fd = open(file, O_RDONLY)) == -1)
    {
      my_printf("%COLOR[Error] %COLOROpen() has failed.\n", "RED", "WHITE");
      exit(0);
    }
  data_file->nbr_lines = gimme_nbr_lines(file);
  gimme_map(fd, data_file);
  check_map(data_file);
  close(fd);
}
