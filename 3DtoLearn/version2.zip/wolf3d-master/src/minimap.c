/*
** minimap.c for minimap in /home/ninon_s//Dropbox/Epitech/current/wolf3D/src
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Fri Jan  4 12:42:29 2013 simon ninon
** Last update Fri Jan 11 17:27:33 2013 simon ninon
*/

#include <math.h>
#include "mlx.h"
#include "wolf.h"

void	put_angle(t_data *data)
{
  int		case_x;
  int		case_y;
  float	angle;

  data->draw->blue = 0;
  data->draw->green = 0;
  data->draw->red = 255;
  case_x = CASE_SIZE_X(data->file->size_line);
  case_y = CASE_SIZE_Y(data->file->nbr_lines);
  angle = ANGLE_MAX(data->perso->angle) + 360;
  while (angle > ANGLE_MIN(data->perso->angle) + 360)
    {
      data->draw->x = data->perso->x / 5;
      data->draw->y = data->perso->y / 5;
      while (data->file->map[(int)data->draw->y * 5 / case_y]
	     [(int)data->draw->x * 5 / case_x] == 0)
	{
	  my_pixel_put_to_image(data->img, data->win, data->draw);
	  data->draw->x += cos((angle - 360) * 3.14 / 180);
	  data->draw->y -= sin((angle - 360) * 3.14 / 180);
	}
      angle -= 0.1;
    }
}

void	put_minimap_background(t_win *win, t_img *img, t_draw *draw)
{
  draw->y = 0;
  draw->green = 255;
  draw->blue = 255;
  draw->red = 255;
  while (draw->y < IMG_SIZE_Y / 5)
    {
      draw->x = 0;
      while (draw->x < IMG_SIZE_X / 5)
	{
	  my_pixel_put_to_image(img, win, draw);
	  draw->x++;
	}
      draw->y++;
    }
}

void	put_obs(t_data *data, int y, int x)
{
  data->draw->blue = 0;
  data->draw->green = 0;
  data->draw->red = 0;
  data->draw->y = y;
  while (data->draw->y < y + CASE_SIZE_Y(data->file->nbr_lines) / 5)
    {
      data->draw->x = x;
      while (data->draw->x < x + CASE_SIZE_X(data->file->size_line) / 5)
	{
	  my_pixel_put_to_image(data->img, data->win, data->draw);
	  data->draw->x++;
	}
      data->draw->y++;
    }
}

void		put_perso(t_data *data)
{
  float	max_x;
  float	max_y;

  data->draw->y = data->perso->y / 5;
  data->draw->red = 255;
  data->draw->blue = 0;
  data->draw->green = 0;
  max_x = CASE_SIZE_X(data->file->size_line) / data->perso->speed;
  max_y = CASE_SIZE_Y(data->file->nbr_lines) / data->perso->speed;
  while (data->draw->y < (data->perso->y + max_y) / 5)
    {
      data->draw->x = data->perso->x / 5;
      while (data->draw->x < (data->perso->x + max_x) / 5)
	{
	  my_pixel_put_to_image(data->img, data->win, data->draw);
	  data->draw->x++;
	}
      data->draw->y++;
    }
}

void	put_minimap(t_data *data)
{
  int	i;
  int	j;

  i = 0;
  put_minimap_background(data->win, data->img, data->draw);
  while (i < data->file->nbr_lines)
    {
      j = 0;
      while (j < data->file->size_line)
	{
	  if (data->file->map[i][j])
	    put_obs(data,
		    i * CASE_SIZE_Y(data->file->nbr_lines) / 5,
		    j * CASE_SIZE_X(data->file->size_line) / 5);
	  j++;
	}
      i++;
    }
  put_perso(data);
}
