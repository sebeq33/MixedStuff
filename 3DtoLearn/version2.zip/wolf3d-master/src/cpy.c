/*
** cpy.c for cpy in /home/ninon_s//Dropbox/Epitech/current/wolf3D
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Fri Jan 11 18:27:29 2013 simon ninon
** Last update Fri Jan 11 20:46:19 2013 simon ninon
*/

#include "my.h"
#include "mlx.h"
#include "wolf.h"

void	cpy_img(t_data *data)
{
  int	i;
  int	x;
  int	y;

  data->draw->x = 0;
  while (data->draw->x < IMG_SIZE_X)
    {
      i = 0;
      x = (int)data->draw->x * data->img->bpp / 8;
      y = (int)data->draw->y * data->img->size_line;
      data->img->data[x + i + y] = data->background->data[x + i++ + y];
      data->img->data[x + i + y] = data->background->data[x + i++ + y];
      data->img->data[x + i + y] = data->background->data[x + i++ + y];
      data->draw->x++;
    }
}

void	cpy_floor(t_data *data)
{
  int	i;
  int	x;
  int	y;
  int	y_floor;

  data->draw->x = 0;
  while (data->draw->x < IMG_SIZE_X)
    {
      i = 0;
      x = (int)data->draw->x * data->img->bpp / 8;
      y = (int)data->draw->y * data->img->size_line;
      y_floor = (int)((data->draw->y - 300) * data->img->size_line);
      data->img->data[x + i + y] = data->floor->data[x + i++ + y_floor];
      data->img->data[x + i + y] = data->floor->data[x + i++ + y_floor];
      data->img->data[x + i + y] = data->floor->data[x + i++ + y_floor];
      data->draw->x++;
    }

}

void	cpy_gun(t_data *data)
{
  int	x;
  int	y;
  int	x_gun;
  int	y_gun;

  data->draw->y = -1;
  while (++data->draw->y + 300 < IMG_SIZE_Y)
    {
      data->draw->x = -1;
      while (++data->draw->x < data->gun->x)
	{
	  x = (int)(data->draw->x + 150)* data->img->bpp / 8;
	  y = (int)(data->draw->y + 300) * data->img->size_line;
	  x_gun = (int)data->draw->x * data->gun->bpp / 8;
	  y_gun = (int)data->draw->y * data->gun->size_line;
	  if (data->gun->data[x_gun + y_gun]
	      || data->gun->data[x_gun + 1 + y_gun + 1]
	      || data->gun->data[x_gun + 2 + y_gun + 2])
	    {
	      data->img->data[x + y] = data->gun->data[x_gun + y_gun];
	      data->img->data[x + 1 + y] = data->gun->data[x_gun + 1 + y_gun];
	      data->img->data[x + 2 + y] = data->gun->data[x_gun + 2 + y_gun];
	    }
	}
    }
}
