/*
** main.c for main in /home/ninon_s//Makefile
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Fri Nov 23 17:52:28 2012 simon ninon
** Last update Sun Jan 13 18:07:06 2013 simon ninon
*/

#include <X11/X.h>
#include <stdlib.h>
#include "mlx.h"
#include "wolf.h"
#include "my_printf.h"

void	check_maccro()
{
  if (WIN_SIZE_X != 600 || WIN_SIZE_Y != 650 || IMG_SIZE_X != 600
      || IMG_SIZE_Y != 600 || IMG_POS_X != 0 || IMG_POS_Y != 0)
    {
      my_printf("%COLOR[Error] %COLORWrong maccros.\n", "RED", "WHITE");
      exit(0);
    }
}

void	text(t_data *data)
{
  mlx_string_put(data->win->mlx_ptr, data->win->win_ptr, 10,
		 WIN_SIZE_Y - 30, 0x00FF00, "Wolf 3D");
  mlx_string_put(data->win->mlx_ptr, data->win->win_ptr, 10,
		 WIN_SIZE_Y - 10, 0x00FF00, "ninon_s");
  mlx_string_put(data->win->mlx_ptr, data->win->win_ptr, 70,
		 WIN_SIZE_Y - 30, 0xFFFFFF, "LEFT - RIGHT: Turn");
  mlx_string_put(data->win->mlx_ptr, data->win->win_ptr, 70,
		 WIN_SIZE_Y - 10, 0xFFFFFF, "UP - DOWN: Move");
  mlx_string_put(data->win->mlx_ptr, data->win->win_ptr, 190,
		 WIN_SIZE_Y - 30, 0xFFFFFF, "SPACE: Remove block");
  mlx_string_put(data->win->mlx_ptr, data->win->win_ptr, 190,
		 WIN_SIZE_Y - 10, 0xFFFFFF, "Enter: Add block");
  mlx_string_put(data->win->mlx_ptr, data->win->win_ptr, 320,
		 WIN_SIZE_Y - 30, 0xFFFFFF, "M: Minimap");
  mlx_string_put(data->win->mlx_ptr, data->win->win_ptr, 320,
		 WIN_SIZE_Y - 10, 0xFFFFFF, "ESC: Exit");
  mlx_string_put(data->win->mlx_ptr, data->win->win_ptr, 400,
		 WIN_SIZE_Y - 30, 0xFFFFFF, "+: Upgrade quality");
  mlx_string_put(data->win->mlx_ptr, data->win->win_ptr, 400,
		 WIN_SIZE_Y - 10, 0xFFFFFF, "-: Downgrade quality");
  mlx_string_put(data->win->mlx_ptr, data->win->win_ptr, 540,
		 WIN_SIZE_Y - 30, 0xFFFFFF, "S: Save");
  mlx_string_put(data->win->mlx_ptr, data->win->win_ptr, 540,
		 WIN_SIZE_Y - 10, 0xFFFFFF, "MAJ: Run");
}

void		wolf(char *file)
{
  t_data	*data;

  check_maccro();
  data = init_struct(data);
  gimme_data(data->file, file);
  init_perso(data->perso, data->file);
  gimme_win(data->win);
  gimme_img(data->win, data->img);
  gimme_sky(data);
  gimme_floor(data);
  gimme_gun(data);
  text(data);
  lets_draw(data);
  mlx_expose_hook(data->win->win_ptr, &check_expose_hook, data);
  mlx_hook(data->win->win_ptr, KeyPress, KeyRelease, &check_key_hook, data);
  mlx_loop(data->win->mlx_ptr);
}

int	main(int ac, char **av)
{
  if (ac == 2)
    wolf(av[1]);
  else
    my_printf("%COLORUsage: %COLOR./wolf3d < file >\n", "RED", "WHITE");
  return (0);
}
