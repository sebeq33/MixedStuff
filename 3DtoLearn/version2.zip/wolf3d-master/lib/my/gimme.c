/*
** gimme.c for gimme in /home/ninon_s//printf
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Mon Nov 12 17:00:15 2012 simon ninon
** Last update Thu Jan  3 20:09:13 2013 simon ninon
*/

#include <stdlib.h>
#include "my_printf.h"
#include "my.h"

int	gimme_unsigned_int(int nbr, int width)
{
  int	size_nbr;
  int	i;

  size_nbr = gimme_unsigned_size(nbr);
  i = width - size_nbr;
  while (width > 0 && i-- > 0)
    my_putchar(' ');
  my_put_long_nbr(nbr);
  i = width * -1 - size_nbr;
  while (width < 0 && i-- > 0)
    my_putchar(' ');
  if (width < 0)
    width = width * -1;
  if (width > size_nbr)
    return (width);
  return (size_nbr);
}

int	gimme_int(int nbr, int width)
{
  int	size_nbr;
  int	i;

  size_nbr = gimme_size_nbr(nbr);
  i = width - size_nbr;
  while (width > 0 && i-- > 0)
    my_putchar(' ');
  my_put_nbr(nbr);
  i = width * -1 - size_nbr;
  while (width < 0 && i-- > 0)
    my_putchar(' ');
  if (width < 0)
    width = width * -1;
  if (width > size_nbr)
    return (width);
  return (size_nbr);
}

int	gimme_str(char *str, int width)
{
  int	i;

 if (str == NULL)
    {
      my_putstr("(null)");
      return (6);
    }
  i = my_strlen(str);
  while (width > i++)
    my_putchar(' ');
  i = my_strlen(str);
  my_putstr(str);
  while (width < 0 && (width * -1) > i++)
    my_putchar(' ');
  if (width < 0)
    width = width * -1;
  i = my_strlen(str);
  if (width > i)
    return (width);
  return (i);
}

int	gimme_char(unsigned char c, int width)
{
  int	i;

  i = width;
  while (i-- > 1)
    my_putchar(' ');
  my_putchar(c);
  i = width;
  while (i++ < -1)
    my_putchar(' ');
  if (width > 1)
    return (width);
  else if (width < -1)
    return (width * -1);
  return (1);
}

void	my_put_long_nbr(long nbr)
{
  if (nbr >= 10 || nbr <= -10)
    my_put_nbr(nbr / 10);
  else if (nbr < 0)
    my_putchar('-');
  if (nbr > 0)
    my_putchar('0' + (nbr % 10));
  else
    my_putchar('0' - (nbr % 10));
}
