/*
** my_strcmp.c for my_strcmp in /home/ninon_s/
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Mon Oct  8 16:53:46 2012 simon ninon
** Last update Thu Jan  3 20:11:20 2013 simon ninon
*/

#include "my.h"

int	my_strcmp(char *s1, char *s2)
{
  int	i;

  i = 0;
  while (s1[i] && s2[i])
    {
      if (s1[i] < s2[i])
	return (s1[i] - s2[i]);
      else if (s1[i] > s2[i])
	return (s1[i] - s2[i]);
      i = i + 1;
    }
  if (!(s1[i]) && !(s2[i]))
    return (0);
  else if (s1[i])
    return (s1[i]);
  else
    return (s2[i] * (-1));
}
