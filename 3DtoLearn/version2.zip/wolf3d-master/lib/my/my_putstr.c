/*
** my_putstr.c for my_putstr in /home/ninon_s/
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Thu Oct  4 14:59:57 2012 simon ninon
** Last update Thu Jan  3 20:10:39 2013 simon ninon
*/

#include <stdlib.h>
#include "my.h"

void	my_putstr(char *str)
{
  if (str != NULL)
    while (*str)
      {
	my_putchar(*str);
	str = str + 1;
      }
}
