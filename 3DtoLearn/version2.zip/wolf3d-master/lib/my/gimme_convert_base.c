/*
** gimme_convert_base.c for gimme_convert_base in /home/ninon_s//printf
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Mon Nov 12 17:13:47 2012 simon ninon
** Last update Thu Jan  3 20:09:25 2013 simon ninon
*/

#include <stdlib.h>
#include "my_printf.h"
#include "my.h"

int	my_put_nbr_base(unsigned int nbr, int base, int up_case, int sharp)
{
  int	modulo;
  int	i;

  i = 1;
  if (sharp && base == 8)
    my_putchar('0');
  else if (sharp && base == 16)
    my_putstr("0x");
  modulo = nbr % base;
  nbr = nbr / base;
  if (nbr)
    i += my_put_nbr_base(nbr, base, up_case, 0);
  if (modulo < 10)
    my_put_nbr(modulo);
  else if (up_case)
    my_putchar('A' + modulo % 10);
  else
    my_putchar('a' + modulo % 10);
  return (i);
}

int	gimme_ptr(void *ptr)
{
  int	i;

  i = 2;
  if (ptr == NULL)
    {
      my_putstr("(nil)");
      return (5);
    }
  my_putstr("0x");
  i += gimme_ptr_adress((unsigned long)ptr);
  return (i);
}

int	gimme_ptr_adress(unsigned long nbr)
{
  int	modulo;
  int	i;

  i = 1;
  modulo = nbr % 16;
  nbr = nbr / 16;
  if (nbr)
    i += gimme_ptr_adress(nbr);
  if (modulo < 10)
    my_put_nbr(modulo);
  else
    my_putchar('a' + modulo % 10);
  return (i);
}

int	transform_hiden_char(char *str)
{
  my_putchar('\\');
  if (*str < 8)
    my_putstr("00");
  else if (*str < 32)
    my_putchar('0');
  my_put_nbr_base(*str, 8, 0, 0);
  return (3);
}

int	gimme_hiden_char(char *str)
{
  int	i;

  if (str == NULL)
    {
      my_putstr("(null)");
      return (6);
    }
  i = my_strlen(str);
  while (*str)
    {
      if (*str < 32 || *str == 127)
	i += transform_hiden_char(str);
      else
	my_putchar(*str);
      str = str + 1;
    }
  return (i);
}
