/*
** new_printf.c for printf in /home/ninon_s//printf
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Wed Nov 14 15:48:56 2012 simon ninon
** Last update Thu Jan  3 20:10:00 2013 simon ninon
*/

#include <stdarg.h>
#include "my_printf.h"
#include "my.h"

int	aff_flag(const char **str, va_list ap, int width, int sharp)
{
  if (**str == 'd' || **str == 'i')
    return (gimme_int(va_arg(ap, int), width));
  else if (**str == 'u')
    return (gimme_unsigned_int(va_arg(ap, int), width));
  else if (**str == 'c')
    return (gimme_char(va_arg(ap, int), width));
  else if (**str == 's')
    return (gimme_str(va_arg(ap, char*), width));
  else if (**str == 'b')
    return (my_put_nbr_base(va_arg(ap, int), 2, 0, 0));
  else if (**str == 'o')
    return (my_put_nbr_base(va_arg(ap, int), 8, 0, sharp));
  else if (**str == 'x')
    return (my_put_nbr_base(va_arg(ap, int), 16, 0, sharp));
  else if (**str == 'X')
    return (my_put_nbr_base(va_arg(ap, int), 16, 1, sharp));
  else if (**str == 'S')
    return (gimme_hiden_char(va_arg(ap, char*)));
  else if (**str == 'p')
    return (gimme_ptr(va_arg(ap, void*)));
  else if (**str == 'C')
    *str = *str + check_color(*str, ap);
  return (0);
}

int	gimme_flag(const char **str, va_list ap)
{
  int	width;
  int	sharp;

  sharp = 0;
  if (**str == '#')
    {
      sharp = 1;
      *str = *str + 1;
    }
  width = my_getnbr((char *)*str);
  while ((**str >= '0' && **str <= '9') || **str == '-' || **str == '+')
    *str = *str + 1;
  return (aff_flag(str, ap, width, sharp));
}

int	check_flag_two(const char **str, va_list ap)
{
  if ((**str >= '0' && **str <= '9') || **str == '-' || **str == '#')
    return (gimme_flag(str, ap));
  else if (**str == 'd' || **str == 'i' || **str == 'u' || **str == 'c'
	   || **str == 's' || **str == 'b' || **str == 'o' || **str == 'x'
	   || **str == 'X' || **str == 'p' || **str == 'S' || **str == 'C')
    return (aff_flag(str, ap, 0, 0));
  else
    {
      my_putchar('%');
      my_putchar(**str);
      return (2);
    }
}

int	check_flag(const char **str, va_list ap, int nbr_caracts)
{
  *str = *str + 1;
  if (**str == ' ' || ** str == '+')
    {
      my_putchar(**str);
      *str = *str + 1;
    }
  if (**str == 'l')
    *str = *str + 1;
  if (**str == '%')
    {
      my_putchar('%');
      return (1);
    }
  else if (**str == 'n')
    {
      *(va_arg(ap, int*)) = nbr_caracts;
      return (0);
    }
  else
    return (check_flag_two(str, ap));
}

int	my_printf(const char *format, ...)
{
  va_list       ap;
  int           nbr_caracts;

  nbr_caracts = 0;
  va_start(ap, format);
  while (*format != 0)
    {
      if (*format == '%')
	nbr_caracts += check_flag(&format, ap, nbr_caracts);
      else
	{
	  my_putchar(*format);
	  nbr_caracts = nbr_caracts + 1;
	}
      format = format + 1;
    }
  va_end(ap);
  WHITE;
  return (nbr_caracts);
}
