/*
** printf.h for printf in /home/ninon_s//printf
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Thu Nov 15 19:48:53 2012 simon ninon
** Last update Fri Jan 11 15:34:27 2013 simon ninon
*/

#ifndef _PRINTF_H_
# define _PRINTF_H_

# include <stdarg.h>

# define RED	"\033[1;31m"
# define CYAN	"\033[1;36m"
# define GREEN	"\033[1;32m"
# define BLACK	"\033[1;30m"
# define YELLOW	"\033[1;33m"
# define BLUE	"\033[1;34m"
# define PURPLE	"\033[1;35m"
# define GREY	"\033[1;37m"
# define WHITE	"\033[0m"

int	my_printf(const char *, ...);
int	check_flag(const char **, va_list, int);
int	check_flag_two(const char **, va_list);
int	gimme_flag(const char **, va_list);
int	aff_flag(const char **, va_list, int, int);
int	gimme_unsigned_int(int, int);
int	gimme_int(int, int);
int	gimme_str(char *, int);
int	gimme_char(unsigned char, int);
int	my_put_nbr_base(unsigned int, int, int, int);
int	gimme_ptr(void *);
int	gimme_ptr_adress(unsigned long );
int	transform_hiden_char(char *);
int	gimme_hiden_char(char *);
int	gimme_size_nbr(int);
int	gimme_unsigned_size(unsigned int);
int	check_color_flag(const char *);
void	put_color(char *);
int	check_color(const char *, va_list);
void	my_put_long_nbr(long);

#endif /* !_PRINTF_H_ */
