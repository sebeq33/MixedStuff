/*
** wolf.h for wolf in /home/ninon_s//Dropbox/Epitech/current/new_wolf3D/src
**
** Made by simon ninon
** Login   <ninon_s@epitech.net>
**
** Started on  Mon Dec 31 17:17:48 2012 simon ninon
** Last update Sun Jan 13 21:23:53 2013 simon ninon
*/

#ifndef WOLF_H
# define WOLF_H

typedef struct	s_perso
{
  float		x;
  float		y;
  float		precision;
  int		angle;
  int		speed;
}		t_perso;

typedef struct	s_win
{
  void		*win_ptr;
  void		*mlx_ptr;
}		t_win;

typedef struct	s_img
{
  void		*img_ptr;
  int		bpp;
  int		size_line;
  int		endian;
  char		*data;
  int		x;
  int		y;
}		t_img;

typedef struct	s_file
{
  int		nbr_lines;
  int		size_line;
  int		**map;
}		t_file;

typedef struct	s_draw
{
  float		x;
  float		y;
  int		blue;
  int		green;
  int		red;
  int		minimap;
}		t_draw;

typedef struct	s_data
{
  t_file	*file;
  t_win		*win;
  t_img		*img;
  t_img		*background;
  t_img		*floor;
  t_img		*gun;
  t_draw	*draw;
  t_perso	*perso;
}		t_data;

/*
** Maccros Win
*/
# define WIN_SIZE_X	600
# define WIN_SIZE_Y	650
# define WIN_NAME	"Wolf3D | ninon_s"

/*
** Maccros Img
*/
# define IMG_SIZE_X	600
# define IMG_SIZE_Y	600
# define IMG_POS_X	0
# define IMG_POS_Y	0

/*
** Maccros Keys
*/
# define ESC		65307
# define LEFT		65361
# define RIGHT		65363
# define UP		65362
# define DOWN		65364
# define MINIMAP	109
# define PLUS		65451
# define MINUS		65453
# define ENTER		65293
# define SPACE		32
# define SAVE		115
# define RUN		65506

/*
** Maccros déplacement
*/
# define CASE_SIZE_X(x)	IMG_SIZE_X / (x)
# define CASE_SIZE_Y(x)	IMG_SIZE_Y / (x)

/*
** Maccros angle
*/
# define ANGLE_MIN(x)	(x) - 30
# define ANGLE_MAX(x)	(x) + 30
# define RADIAN(x)	(x) * 3.14 / 180

/*
** main.c
*/
void	wolf(char *);
void	text(t_data *);

/*
** init.c
*/
t_data	*init_struct(t_data *);
void	transform_in_int(char *, int *, int *);
void	gimme_data(t_file *, char *);
void	init_perso(t_perso *, t_file *);
void	check_map(t_file *);

/*
** hook.c
*/
int	check_expose_hook(t_data *);
int	check_key_hook(int , t_data *);
void	free_all(t_data *);
void	check_actions(t_data *, int);

/*
** gimme.c
*/
void	gimme_map(int, t_file *);
void	gimme_win(t_win *);
void	gimme_img(t_win *, t_img *);
int	gimme_nbr_lines(char *);
void	gimme_color(t_data *, double, double, double);

/*
** draw.c
*/
void	put_wall(t_data *, double);
void	lets_draw(t_data *);
void	find_intersection(t_data *, int, int, float);
void	search_walls(t_data *);

/*
** background.c
*/
void	put_background(t_data *);

/*
** cpy;c
*/
void	cpy_img(t_data *);
void	cpy_floor(t_data *);
void	cpy_gun(t_data *);

/*
** color.c
*/
void	color_one(t_data *);
void	color_two(t_data *);
void	color_three(t_data *);
void	color_four(t_data *);

/*
** gimme_pattern.c
*/
void	gimme_sky(t_data *);
void	gimme_floor(t_data *);

/*
** keys.c
*/
void	right(t_data *);
void	left(t_data *);
void	up(t_data *);
void	down(t_data *);

/*
** minecraft.c
*/
void	add_block(t_data *);
void	remove_block(t_data *);

/*
** minimap.c
*/
void	put_angle(t_data *);
void	put_minimap_background(t_win *, t_img *, t_draw *);
void	put_obs(t_data *, int, int);

/*
** pixel_put_to_image.c
*/
void	my_pixel_put_to_image(t_img *, t_win *, t_draw *);

#endif /* !WOLF_H_ */
